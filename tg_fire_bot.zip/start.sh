#!/bin/bash
python tg_fire_bot.py